<?php
// Copyright (c) 2013-2015 Datenstrom, http://datenstrom.se
// This file may be used and distributed under the terms of the public license.

// Antispam plugin
class YellowAntispam
{
	const Version = "0.7.5";
	var $yellow;			//access to API
	
	// Handle initialisation
	function onLoad($yellow)
	{
		$this->yellow = $yellow;
	}
	
	// Handle page content parsing of custom block
	function onParseContentBlock($page, $name, $text, $shortcut)
	{
		$output = NULL;
		if($name=="email" && $shortcut)
		{
			list($address, $displaytext) = $this->yellow->toolbox->getTextArgs($text);
			if(empty($displaytext)) $displaytext = null;
			$output = $this->email($address, $displaytext);
		}
		return $output;
	}
	
	/** @author Roman Ozana <ozana@omdesign.cz> */
	/**
	 * Obfuscate email addresses and protect them against SPAM bots.
	 *
	 * @see http://techblog.tilllate.com/2008/07/20/ten-methods-to-obfuscate-e-mail-addresses-compared/
	 * @see https://perishablepress.com/best-method-for-email-obfuscation/
	 *
	 * @param string $email
	 * @param string $text
	 * @param string $format
	 * @return string
	 */
	function email($email, $text = null, $format = "<a href=\"mailto:%s\" rel=\"nofollow\">%s</a>") {
		return $this->html(
			sprintf($format, htmlspecialchars($email, ENT_QUOTES), $text ? htmlspecialchars($text, ENT_QUOTES) : $email)
		) .
		"<noscript><span style=\"unicode-bidi: bidi-override; direction: rtl;\">" . strrev($email) . "</span></noscript>";
	}
	
	/**
	 * Protect HTML code with rot13 then transform code back with Javascript.
	 *
	 * @param string $html
	 * @return string
	 */
	function html($html) {
		return "<script type=\"text/javascript\">/* <![CDATA[ */document.write(\"" .
		addslashes(
			str_rot13($html)
		) . "\".replace(/[a-zA-Z]/g,function(c){return String.fromCharCode((c<=\"Z\"?90:122)>=(c=c.charCodeAt(0)+13)?c:c-26);}));/* ]]> */</script>";
	}
}

$yellow->plugins->register("antispam", "YellowAntispam", YellowAntispam::Version);
?>