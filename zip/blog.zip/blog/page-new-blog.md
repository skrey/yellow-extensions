---
Title: Blog page
Published: @datetime
Author: @username
Layout: blog
Tag: Example
---
This is a new blog page.