<?php
// TuneIn Radio plugin
// Copyright (c) 2018 Steffen Schultz
// This file may be used and distributed under the terms of the public license.

class YellowTunein
{
	const VERSION = "0.7.2";
	var $yellow;			//access to API
	
	// Handle initialisation
	function onLoad($yellow)
	{
		$this->yellow = $yellow;
		$this->yellow->config->setDefault("tuneinStyle", "tunein");
	}
	
	// Handle page content parsing of custom block
	function onParseContentBlock($page, $name, $text, $shortcut)
	{
		$output = null;
		if($name=="tunein" && $shortcut)
		{
			list($id, $style, $width, $height, $autoplay) = $this->yellow->toolbox->getTextArgs($text);
			if(empty($style)) $style = $this->yellow->config->get("tuneinStyle");
			if(empty($width)) $width = "100%";
			if(empty($height)) $height = "100px";
			if(empty($autoplay)) $autoplay = "false";
			$output = "<div class=\"".htmlspecialchars($style)."\">";
			$output .= "<iframe src=\"https://tunein.com/embed/player/".rawurlencode($id)."/?autoplay=".htmlspecialchars($autoplay)."\" style=\"width:".htmlspecialchars($width)."; height:".htmlspecialchars($height).";\" scrolling=\"no\" frameborder=\"no\"";
			$output .= "></iframe></div>";
		}
		return $output;
	}
}

$yellow->plugins->register("tunein", "YellowTunein", YellowTunein::VERSION);
?>