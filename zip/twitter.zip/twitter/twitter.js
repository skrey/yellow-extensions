// Twitter plugin, https://github.com/datenstrom/yellow-plugins/tree/master/twitter
// Copyright (c) 2013-2017 Datenstrom, https://datenstrom.se
// This file may be used and distributed under the terms of the public license.

window.twttr = (function(d, s, id)
{
	var js, fjs = d.getElementsByTagName(s)[0], t = window.twttr || {};
	if (d.getElementById(id)) return t;
	js = d.createElement(s);
	js.id = id;
	js.src = "https://platform.twitter.com/widgets.js";
	fjs.parentNode.insertBefore(js, fjs);
	t._e = [];
	t.ready = function(f) { t._e.push(f); };
	return t;
}(document, "script", "twitter-wjs"));

function TwitterMessage(element, options)
{
	this.element = element;
	this.options = options ? options : this.parseOptions(element, ["tweetLimit", "borderColor", "linkColor", "ariaPolite"]);
	return (this instanceof TwitterMessage ? this : new TwitterMessage());
}

TwitterMessage.prototype =
{
	// Parse Twitter options
	parseOptions: function(element, keyNames)
	{
		var options = {};
		for(var i=0; i<element.attributes.length; i++)
		{
			var attribute = element.attributes[i], key, value;
			if(attribute.nodeName.substr(0, 5)=="data-")
			{
				key = attribute.nodeName.substr(5);
				for(var j=0; j<keyNames.length; j++)
				{
					if(key==keyNames[j].toLowerCase())
					{
						key = keyNames[j];
						break;
					}
				}
				switch(attribute.nodeValue)
				{
					case "true": value = true; break;
					case "false": value = false; break;
					default: value = attribute.nodeValue;
				}
				options[key] = value;
			}
		}
		return options;
	},
	
	// Show Twitter error
	onShowError: function(result)
	{
		var node = document.createTextNode("Twitter '"+this.options.id+"' not available!");
		this.element.appendChild(node);
	},
	
	// Request Twitter data
	request: function()
	{
		if(twttr.widgets)
		{
			var thisObject = this, promise;
			switch(this.options.mode)
			{
				case "tweet":
					promise = twttr.widgets.createTweet(this.options.id, this.element, this.options);
					promise.then(function(result) { if(result==null) { thisObject.onShowError(result); }});
					break;
				case "timeline":
					promise = twttr.widgets.createTimeline({ sourceType: "url", url: "https://twitter.com/"+this.options.id }, this.element, this.options);
					promise.then(function(result) { if(result==null) { thisObject.onShowError(result); }});
					break;
			}
		} else {
			this.onShowError("offline");
		}
	}
}

var initTwitterFromDOM = function()
{
	var twitters = {};
	var twitterElements = document.querySelectorAll(".twitter");
	for(var i=0, l=twitterElements.length; i<l; i++)
	{
		twitters[i] = new TwitterMessage(twitterElements[i]);
		twitters[i].request();
	}
};

if(window.addEventListener) {
	window.addEventListener("load", initTwitterFromDOM, false);
} else {
	window.attachEvent("onload", initTwitterFromDOM);
}
