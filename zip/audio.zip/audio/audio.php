<?php
// Audio plugin, https://github.com/schulle4u/yellow-plugin-audio
// Copyright (c) 2013-2015 Datenstrom, https://datenstrom.se
// This file may be used and distributed under the terms of the public license.

class YellowAudio
{
	const VERSION = "0.6.8";
	var $yellow;			//access to API
	
	// Handle initialisation
	function onLoad($yellow)
	{
		$this->yellow = $yellow;
		$this->yellow->config->setDefault("audioDownload", "0");
		$this->yellow->config->setDefault("audioUrlPrefix", "");
		$this->yellow->config->setDefault("audioStyle", "audio");
	}
	
	// Handle page content parsing of custom block
	function onParseContentBlock($page, $name, $text, $shortcut)
	{
		$output = NULL;
		if($name=="audio" && $shortcut)
		{
			list($url, $download, $style) = $this->yellow->toolbox->getTextArgs($text);
			$url = $this->yellow->config->get("audioUrlPrefix").$url;
			if(!preg_match("/^\w+:/", $url))
			{
				$url = $this->yellow->config->get("serverBase").$url;
			} else {
				$url = $this->yellow->lookup->normaliseUrl("", "", "", $url);
			}
			if(strempty($download)) $download = $this->yellow->config->get("audioDownload");
			if(empty($style)) $style = $this->yellow->config->get("audioStyle");
			$output = "<div class=\"".htmlspecialchars($style)."\">\n";
			$output .= "<audio src=\"".htmlspecialchars($url)."\" controls=\"controls\">HTML5 audio not supported.</audio>\n";
			if($download)
			{
				$output .= "<p><a href=\"".htmlspecialchars($url)."\">Download</a></p>\n";
			}
			$output .="</div>\n";
		}
		if($name=="audiostream" && $shortcut)
		{
			list($url, $style) = $this->yellow->toolbox->getTextArgs($text);
			$url = $this->yellow->lookup->normaliseUrl("", "", "", $url);
			if(empty($style)) $style = $this->yellow->config->get("audioStyle");
			$output = "<div class=\"".htmlspecialchars($style)."\">\n";
			$output .= "<audio src=\"".htmlspecialchars($url)."\" controls=\"controls\">HTML5 audio not supported.</audio>\n";
			$output .="</div>\n";
		}
		return $output;
	}
}

$yellow->plugins->register("audio", "YellowAudio", YellowAudio::VERSION);
?>
