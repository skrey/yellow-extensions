<?php
// Copyright (c) 2013-2015 Datenstrom, http://datenstrom.se
// This file may be used and distributed under the terms of the public license.

// HTML5 audio player plugin
class YellowAudio
{
	const Version = "0.6.6";
	var $yellow;			//access to API
	
	// Handle initialisation
	function onLoad($yellow)
	{
		$this->yellow = $yellow;
		$this->yellow->config->setDefault("audioBase", "");
		$this->yellow->config->setDefault("audioStyle", "audio");
	}
	
	// Handle page content parsing of custom block
	function onParseContentBlock($page, $name, $text, $shortcut)
	{
		$output = NULL;
		if($name=="audio" && $shortcut)
		{
			list($audiourl, $allow_dl, $prefix, $style) = $this->yellow->toolbox->getTextArgs($text);
			$base = $this->yellow->config->get("audioBase");
			if(strempty($allow_dl)) $allow_dl = 0;
			if(strempty($prefix)) $prefix = 1;
			if(empty($style)) $style = $this->yellow->config->get("audioStyle");
			$output = "<div class=\"".htmlspecialchars($style)."\">\n";
			$output .= "<audio src=\"";
			if($prefix == 1) {
				if($base) $output .= htmlspecialchars($base);
			}
			$output .= htmlspecialchars($audiourl)."\" controls>HTML5 audio not supported. </audio>\n";
			if ($allow_dl == 1) {
				$output .= "<p><a href=\"";
				if($prefix == 1) {
					if($base) $output .= htmlspecialchars($base);
				}
				$output .= htmlspecialchars($audiourl)."\">Download</a></p>\n";
			}
			
			$output .="</div>\n";
		}
		return $output;
	}
}

$yellow->plugins->register("audio", "YellowAudio", YellowAudio::Version);
?>