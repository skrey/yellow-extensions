<?php
// French extension, https://github.com/datenstrom/yellow-extensions/tree/master/languages/french
// Copyright (c) 2013-2019 Datenstrom, https://datenstrom.se
// This file may be used and distributed under the terms of the public license.

class YellowFrench {
    const VERSION = "0.8.2";
    const TYPE = "language";
}
