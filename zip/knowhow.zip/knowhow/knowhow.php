<?php
// Knowhow theme, https://github.com/datenstrom/yellow-themes/tree/master/knowhow
// Copyright (c) 2013-2019 Datenstrom, https://datenstrom.se
// This file may be used and distributed under the terms of the public license.

class YellowThemeKnowhow {
    const VERSION = "0.8.1";
}
