---
Title: Hur man ändrar språket
---
Så här ändrar du språket på din webbplats.

## Enkelspråkigt läge 

Standardspråket definieras [systeminställningarna](how-to-adjust-system#systeminställningar). Ett annat språk kan definieras i [sidinställningarna](how-to-adjust-system#sidinställningar) högst upp på varje sida, till exempel `Language: sv`. 

En svensk sida:

```
---
Title: Om oss
Language: sv
---
Lika barn leka bäst.
```

En engelsk sida:

```
---
Title: About us
Language: en
---
Birds of a feather flock together.
```

En tysk sida:

```
---
Title: Über uns
Language: de
---
Wo zusammenwächst was zusammen gehört.
```

## Flerspråkigt läge

För flerspråkiga webbplatser kan du använda flerspråkigt läge. Till exempel om du översätter en hel webbplats. Öppna filen `system/extensions/yellow-system.ini` och ändra `CoreMultiLanguageMode: 1`. Gå till din innehållsmapp och skapa en ny mapp för varje språk. Här är ett exempel: 

```
├── content               
│   ├── 1-en              
│   │   ├── 1-home        = http://website/
│   │   └── shared    
│   ├── 2-de              
│   │   ├── 1-home        = http://website/de/
│   │   └── shared    
│   └── 3-sv              
│       ├── 1-home        = http://website/sv/
│       └── shared    
├── media                 
└── system                
```

Den första skärmdumpen visar mapparna `1-en`,` 2-de` och `3-sv`. Detta ger dig webbadresserna `http://website/` `http://website/de/` `http://website/sv/` för engelska, tyska och svenska. Här är ett annat exempel: 

```
├── content               
│   ├── 1-en              
│   │   ├── 1-home        = http://website/en/
│   │   └── shared    
│   ├── 2-de              
│   │   ├── 1-home        = http://website/de/
│   │   └── shared    
│   ├── 3-sv              
│   │   ├── 1-home        = http://website/sv/
│   │   └── shared    
│   └── default           = http://website/       
├── media                 
└── system                
```

Den andra skärmdumpen visar mapparna `1-en`,` 2-de`, `3-sv` och `default`. Detta ger dig webbadresserna `http://website/en/` `http://website/de/` `http://website/sv/` och en hemsida `http://website/` som automatiskt upptäcker besökarens språk.

För att visa ett språkval] kan du skapa en sida som visar tillgängliga språk. Språkvalet kan integreras i navigeringen på din webbplats. Detta gör det möjligt för besökare att välja språk. 

Har du några frågor? [Få hjälp](.) och [engagera dig](contributing-guidelines).
