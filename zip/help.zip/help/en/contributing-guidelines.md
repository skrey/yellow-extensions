---
Title: Contributing guidelines
---
Here's how we work together and make good products.

[toc]

## How to ask a question

* [Create a new discussion for each question](https://github.com/datenstrom/yellow/discussions).
* Describe your question and which problems you have.
* Specify the version of your website, use the latest version if possible.
* Add a lot of details, the more we know the better we can help.

## How to report a bug

* [Create a new discussion for each bug](https://github.com/datenstrom/yellow/discussions).
* Explain what doesn't work and how to reproduce the error.
* Check the file `system/extensions/yellow.log` for error messages.
* Add a lot of details, the more we know the better we can help.

## How to make a translation

* [Have a look at your language](https://github.com/datenstrom/yellow-extensions#languages) and the [help extension](https://github.com/datenstrom/yellow-extensions/tree/master/source/help). 
* Look for text lines which have not been translated yet. 
* Make a new translation, if your language is missing.
* Publish your translation in the official repository.

## How to create an extension

* [Start with an example feature](https://github.com/schulle4u/yellow-extension-helloworld) or [example theme](https://github.com/schulle4u/yellow-extension-basic).
* Imagine what the user wants to do, aim for a simple solution.
* Upload your extension to GitHub, let us know if you need help.
* Publish your extension in the official repository.

## Related information

* [Datenstrom on GitHub](https://github.com/datenstrom)
* [Datenstrom on Twitter](https://twitter.com/datendeveloper)
* [API for developers](api-for-developers)
