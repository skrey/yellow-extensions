<?php
// Message of the day plugin
// Copyright (c) 2017 Steffen Schultz 
// This file may be used and distributed under the terms of the public license.

class YellowMotd
{
	const VERSION = "0.7.1";
	var $yellow;			//access to API
	
	// Handle initialisation
	function onLoad($yellow)
	{
		$this->yellow = $yellow;
	}

	// Handle page content parsing of custom block
	function onParseContentBlock($page, $name, $text, $shortcut)
	{
		$output = NULL;
		if($name=="motd" && $shortcut)
		{
			list() = $this->yellow->toolbox->getTextArgs($text);
			$this->yellow->page->setHeader("Cache-Control", "no-store, no-cache, must-revalidate");
			$output .= "<div class=\"motd\">\n";
			
			$dow = date("N");
			
			// Loop through the week
			switch($dow) {
				case 1:
					if($this->yellow->page->isExisting("motd1")) $output .= "<p>".$this->yellow->page->getHtml("motd1")."</p>\n";
					break;
				case 2:
					if($this->yellow->page->isExisting("motd2")) $output .= "<p>".$this->yellow->page->getHtml("motd2")."</p>\n";
					break;
				case 3:
					if($this->yellow->page->isExisting("motd3")) $output .= "<p>".$this->yellow->page->getHtml("motd3")."</p>\n";
					break;
				case 4:
					if($this->yellow->page->isExisting("motd4")) $output .= "<p>".$this->yellow->page->getHtml("motd4")."</p>\n";
					break;
				case 5:
					if($this->yellow->page->isExisting("motd5")) $output .= "<p>".$this->yellow->page->getHtml("motd5")."</p>\n";
					break;
				case 6:
					if($this->yellow->page->isExisting("motd6")) $output .= "<p>".$this->yellow->page->getHtml("motd6")."</p>\n";
					break;
				case 7:
					if($this->yellow->page->isExisting("motd7")) $output .= "<p>".$this->yellow->page->getHtml("motd7")."</p>\n";
					break;
				}
				$output .="</div>\n";
			}
		return $output;
	}
}

$yellow->plugins->register("motd", "YellowMotd", YellowMotd::VERSION);
?>