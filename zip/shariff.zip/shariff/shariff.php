<?php
// Copyright (c) 2013-2016 Datenstrom, http://datenstrom.se
// This file may be used and distributed under the terms of the public license.

// Shariff Plugin
class YellowShariff
{
	const Version = "0.6.5";
	var $yellow;			//access to API
	
	// Handle initialisation
	function onLoad($yellow)
	{
		$this->yellow = $yellow;
		$this->yellow->config->setDefault("shariffType", "min");
		if(!$this->yellow->config->isExisting("jqueryCdn"))
		{
			$this->yellow->config->setDefault("jqueryCdn", "https://cdnjs.cloudflare.com/ajax/libs/jquery/1.11.1/");
		}
	}
	
	// Handle page content parsing of custom block
	function onParseContentBlock($page, $name, $text, $shortcut)
	{
		$output = NULL;
		if($name=="shariff" && $shortcut)
		{
			$output = "<div class=\"shariff\"></div>";
		}
		return $output;
	}
	
	// Handle page extra HTML data
	function onExtra($name)
	{
		$output = NULL;
		if($name == "header")
		{
			$jqueryCdn = $this->yellow->config->get("jqueryCdn");
			$output .= "<script type=\"text/javascript\" src=\"{$jqueryCdn}jquery.min.js\"></script>\n";
			$locationStylesheet = $this->yellow->config->get("serverBase").$this->yellow->config->get("pluginLocation")."shariff.".$this->yellow->config->get("shariffType").".css";
			$fileNameStylesheet = $this->yellow->config->get("pluginDir")."shariff.".$this->yellow->config->get("shariffType").".css";
			if(is_file($fileNameStylesheet)) $output .= "<link rel=\"stylesheet\" type=\"text/css\" media=\"all\" href=\"$locationStylesheet\" />\n";
		}
		if($name == "footer")
		{
			$locationJavascript = $this->yellow->config->get("serverBase").$this->yellow->config->get("pluginLocation")."shariff.".$this->yellow->config->get("shariffType").".js";
			$fileNameJavascript = $this->yellow->config->get("pluginDir")."shariff.".$this->yellow->config->get("shariffType").".js";
			if(is_file($fileNameJavascript)) $output = "<script type=\"text/javascript\" src=\"$locationJavascript\"></script>\n";
		}
		return $output;
	}
}

$yellow->plugins->register("shariff", "YellowShariff", YellowShariff::Version);
?>